// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

// Code generated from semantic convention specification. DO NOT EDIT.

package semconv

func GetEventSemanticConventionAttributeNames() []string {
	return []string{}
}
