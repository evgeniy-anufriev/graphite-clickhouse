// +build !cairo

package types

type GraphOptions struct {
}
