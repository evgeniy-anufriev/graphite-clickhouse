package rewrite

//go:generate go run ../../internal/generateRewriteFuncs/gen.go
