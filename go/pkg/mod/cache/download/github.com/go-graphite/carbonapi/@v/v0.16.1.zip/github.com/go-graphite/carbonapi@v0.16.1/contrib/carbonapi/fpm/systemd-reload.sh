#!/usr/bin/env bash
[[ -e /bin/systemctl ]] && /bin/systemctl daemon-reload ||:
