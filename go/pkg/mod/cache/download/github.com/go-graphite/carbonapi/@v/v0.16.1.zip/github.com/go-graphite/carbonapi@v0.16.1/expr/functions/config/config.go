package config

var Config = struct {
	ExtractTagsFromArgs bool
}{}
