How to write end-to-end tests for carbonapi
==

Detailed description
-----

TODO

Example yaml configs should be rather self-explanitory though.

Notes on testing cairo/images
-----

Different distros would have different settings (fonts, hinting, patches on top of cairo) so sha256 on one distro for the same image might not match sha256 on another distro.

