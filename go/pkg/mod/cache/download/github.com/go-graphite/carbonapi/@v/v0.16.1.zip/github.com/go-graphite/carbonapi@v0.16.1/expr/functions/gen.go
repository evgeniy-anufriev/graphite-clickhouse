package functions

//go:generate go run ../../internal/generateFuncs/gen.go
