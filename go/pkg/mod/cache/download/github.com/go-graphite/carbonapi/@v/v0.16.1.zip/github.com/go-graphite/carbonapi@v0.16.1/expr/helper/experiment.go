package helper

// ExtrapolatePoints defines if we should extrapolate when we are aligning series together
var ExtrapolatePoints = false
