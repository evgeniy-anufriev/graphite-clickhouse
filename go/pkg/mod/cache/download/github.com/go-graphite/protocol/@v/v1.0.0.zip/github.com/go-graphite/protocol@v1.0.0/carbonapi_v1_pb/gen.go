package carbonapi_v1_pb

//go:generate protoc --gogofast_out=. carbonapi_v1_pb.proto --proto_path=../vendor/ --proto_path=.
