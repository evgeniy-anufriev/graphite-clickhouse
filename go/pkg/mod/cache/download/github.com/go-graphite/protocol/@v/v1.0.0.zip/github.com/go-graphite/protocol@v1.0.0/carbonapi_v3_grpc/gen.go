package carbonapi_v3_grpc

//go:generate protoc --gogoslick_out=plugins=grpc:. carbonapi_v3_grpc.proto --proto_path=../vendor/ --proto_path=. --proto_path=../../../../
