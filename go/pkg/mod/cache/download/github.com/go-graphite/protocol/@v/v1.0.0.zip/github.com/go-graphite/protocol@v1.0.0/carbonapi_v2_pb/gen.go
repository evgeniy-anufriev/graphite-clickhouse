package carbonapi_v2_pb

//go:generate protoc --gogoslick_out=. carbonapi_v2_pb.proto --proto_path=../vendor/ --proto_path=. --proto_path=../
