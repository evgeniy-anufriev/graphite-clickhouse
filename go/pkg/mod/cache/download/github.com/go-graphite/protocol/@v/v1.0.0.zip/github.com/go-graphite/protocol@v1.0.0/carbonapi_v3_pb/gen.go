package carbonapi_v3_pb

//go:generate protoc --gogoslick_out=. carbonapi_v3_pb.proto --proto_path=../vendor/ --proto_path=.
