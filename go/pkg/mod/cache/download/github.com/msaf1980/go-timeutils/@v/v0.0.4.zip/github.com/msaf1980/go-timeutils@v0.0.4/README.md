# go-timeutils

Some time/date routines
