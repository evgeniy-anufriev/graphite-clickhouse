// Copyright (c) 2016-2020 Uber Technologies, Inc.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

package atomic

import (
	"encoding/json"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestStringNoInitialValue(t *testing.T) {
	atom := &String{}
	require.Equal(t, "", atom.Load(), "Initial value should be blank string")
}

func TestString(t *testing.T) {
	atom := NewString("")
	require.Equal(t, "", atom.Load(), "Expected Load to return initialized value")

	atom.Store("abc")
	require.Equal(t, "abc", atom.Load(), "Unexpected value after Store")

	atom = NewString("bcd")
	require.Equal(t, "bcd", atom.Load(), "Expected Load to return initialized value")

	t.Run("JSON/Marshal", func(t *testing.T) {
		bytes, err := json.Marshal(atom)
		require.NoError(t, err, "json.Marshal errored unexpectedly.")
		require.Equal(t, []byte(`"bcd"`), bytes, "json.Marshal encoded the wrong bytes.")
	})

	t.Run("JSON/Unmarshal", func(t *testing.T) {
		err := json.Unmarshal([]byte(`"abc"`), &atom)
		require.NoError(t, err, "json.Unmarshal errored unexpectedly.")
		require.Equal(t, "abc", atom.Load(), "json.Unmarshal didn't set the correct value.")
	})

	t.Run("String", func(t *testing.T) {
		atom := NewString("foo")
		assert.Equal(t, "foo", atom.String(),
			"String() returned an unexpected value.")
	})

	t.Run("CompareAndSwap", func(t *testing.T) {
		atom := NewString("foo")

		swapped := atom.CompareAndSwap("bar", "bar")
		require.False(t, swapped, "swapped isn't false")
		require.Equal(t, atom.Load(), "foo", "Load returned wrong value")

		swapped = atom.CompareAndSwap("foo", "bar")
		require.True(t, swapped, "swapped isn't true")
		require.Equal(t, atom.Load(), "bar", "Load returned wrong value")
	})

	t.Run("Swap", func(t *testing.T) {
		atom := NewString("foo")

		old := atom.Swap("bar")
		require.Equal(t, old, "foo", "Swap returned wrong value")
		require.Equal(t, atom.Load(), "bar", "Load returned wrong value")
	})
}

func TestString_InitializeDefault(t *testing.T) {
	tests := []struct {
		msg    string
		newStr func() *String
	}{
		{
			msg: "Uninitialized",
			newStr: func() *String {
				var s String
				return &s
			},
		},
		{
			msg: "NewString with default",
			newStr: func() *String {
				return NewString("")
			},
		},
		{
			msg: "String swapped with default",
			newStr: func() *String {
				s := NewString("initial")
				s.Swap("")
				return s
			},
		},
		{
			msg: "String CAS'd with default",
			newStr: func() *String {
				s := NewString("initial")
				s.CompareAndSwap("initial", "")
				return s
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.msg, func(t *testing.T) {
			t.Run("MarshalText", func(t *testing.T) {
				str := tt.newStr()
				text, err := str.MarshalText()
				require.NoError(t, err)
				assert.Equal(t, "", string(text), "")
			})

			t.Run("String", func(t *testing.T) {
				str := tt.newStr()
				assert.Equal(t, "", str.String())
			})

			t.Run("CompareAndSwap", func(t *testing.T) {
				str := tt.newStr()
				require.True(t, str.CompareAndSwap("", "new"))
				assert.Equal(t, "new", str.Load())
			})

			t.Run("Swap", func(t *testing.T) {
				str := tt.newStr()
				assert.Equal(t, "", str.Swap("new"))
			})
		})
	}
}
