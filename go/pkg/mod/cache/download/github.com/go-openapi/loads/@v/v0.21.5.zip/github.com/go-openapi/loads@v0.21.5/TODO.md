[x] why not filepath in JSONDoc()
[] integration tests package
[] relint
