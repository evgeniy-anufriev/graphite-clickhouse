# prometheus-ui-static
Precompiled prometheus web ui for embedding
