package carbon

//go:generate protoc -I . carbon.proto --gogofast_out=plugins=grpc:.
