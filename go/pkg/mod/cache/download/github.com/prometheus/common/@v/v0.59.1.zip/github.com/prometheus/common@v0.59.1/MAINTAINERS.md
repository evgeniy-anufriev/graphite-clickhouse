* Julien Pivotto <roidelapluie@prometheus.io> @roidelapluie
* Josue (Josh) Abreu <josue.abreu@gmail.com> @gotjosh
* Arthur Sens <arthur@prometheus.io> @ArthurSens 
