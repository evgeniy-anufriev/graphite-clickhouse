module Views.Shared.Types exposing (Msg)


type alias Msg =
    Maybe String
