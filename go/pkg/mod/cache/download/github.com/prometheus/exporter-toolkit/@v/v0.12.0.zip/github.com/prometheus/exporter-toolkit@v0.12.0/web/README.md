# web package

This package can be used by Prometheus exporters to enable TLS and
authentication.

We actively encourage the community to use this repository, to provide a
consistent experience across the ecosystem.

Developers documentation can be found on
[pkg.go.dev](https://pkg.go.dev/github.com/prometheus/exporter-toolkit/).
